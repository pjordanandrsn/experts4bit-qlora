# Copyright 2026 Axolotl AI. All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0

"""Pydantic args for the expert-offload plugin."""

from typing import Literal

from pydantic import BaseModel, model_validator


class ExpertOffloadArgs(BaseModel):
    """Input args for the expert_offload plugin. See the integration README.

    Axolotl folds plugin args into the full config by inheritance
    (``integrations/config.py::merge_input_args``), so the cross-field validator below runs on
    the merged config and sees the base-config fields (``load_in_4bit``, ``fsdp``, ...); the
    ``getattr`` defaults keep the model instantiable standalone as well.
    """

    expert_offload: bool = False
    """Keep frozen 4-bit MoE experts in CPU RAM and stream one block's experts to the GPU at a time,
    lowering peak VRAM so MoE models whose experts exceed VRAM can QLoRA-train on a small GPU.
    Requires a 4-bit adapter (``load_in_4bit`` + ``adapter: qlora``) and
    ``gradient_checkpointing: true`` with ``use_reentrant: false``. One GPU per replica: single-GPU
    and plain DDP (multi-GPU data parallel) are supported — under DDP each rank homes its own pinned
    copy of the experts, so CPU RAM cost scales with world size. FSDP / DeepSpeed / expert-parallel
    shard or move the same weights and are refused."""

    expert_offload_pin_memory: bool = True
    """Home the offloaded expert weights in pinned CPU memory so the per-block host->device copy is
    truly asynchronous. Set false only if pinned memory is scarce (falls back to a correct but
    synchronous pageable copy)."""

    expert_offload_store: Literal["ram", "file"] = "ram"
    """Where evicted expert blocks live between stagings. ``ram`` (default) keeps each block as a
    (pinned) CPU tensor — today's behavior. ``file`` writes the packed experts once to a read-only
    on-disk store and streams blocks back through small reusable (pinned) staging buffers —
    O_DIRECT when the filesystem supports it, buffered + ``posix_fadvise(DONTNEED)`` otherwise —
    trading staging latency for a host-RAM footprint of ~one block instead of the whole expert
    set. Identical bytes and identical math either way; only the source of the copy differs."""

    expert_offload_staging: str = "whole_layer"
    """``whole_layer`` (default) stages every visited layer's ENTIRE expert stack. ``routed``
    stages only the experts this forward routes to (the distinct top-k union): a full-size GPU
    weight is allocated but only routed rows are filled from the store, so per-forward staging
    traffic is ``read_fraction`` x the layer instead of the whole layer. Bit-identical output
    (un-routed rows are never indexed). ``routed`` runs synchronously (no prefetch — the routing
    is not known a block ahead).

    KNOWN ISSUE (2026-07-10): ``routed`` is bit-identical to whole-layer on a lazy fake MoE but
    DIVERGES on the real e4b/transformers training forward (measured OLMoE loss 11.75 vs 1.214).
    It is gated behind AXOLOTL_EXPERT_OFFLOAD_ROUTED_EXPERIMENTAL=1 and must not be used in
    production until the divergence is root-caused. Default whole_layer is correct and validated."""

    expert_offload_prefetch: bool = False
    """(``file`` store only) Read the predicted next block's bytes from disk into a second
    staging-buffer set while the current block computes — a deterministic double-buffer
    that hides disk latency behind compute. Direction-aware: follows the forward
    (ascending) and gradient-checkpoint recompute (descending) staging orders; a
    mispredicted block is simply discarded and that staging falls back to the synchronous
    read. Host RAM +one block's staging buffers; GPU footprint unchanged. No effect on
    the ``ram`` store."""

    expert_offload_store_dir: str | None = None
    """Directory for the ``file`` store's packed experts (``expert_store.bin`` + index). Defaults
    to a fresh temporary directory. Place it on the fastest LOCAL disk available; a network
    filesystem here turns every block staging into a network read."""

    @model_validator(mode="after")
    def validate_expert_offload_requirements(self):
        if not self.expert_offload:
            return self

        errors: list[str] = []

        # 4-bit experts: the mechanism swaps ``Linear4bit.weight.data``.
        if not getattr(self, "load_in_4bit", False):
            errors.append(
                "requires load_in_4bit: true (it offloads 4-bit Linear4bit experts)"
            )
        if getattr(self, "adapter", None) not in ("lora", "qlora"):
            errors.append("requires adapter: qlora (or lora with load_in_4bit)")

        # Gradient checkpointing (use_reentrant=False) is load-bearing: the backward recompute
        # re-stages each block's experts, and it is what lets eviction actually free memory rather
        # than pin every staged weight alive as a matmul_4bit saved-for-backward tensor.
        # ``use_reentrant`` must be EXPLICITLY false: this validator runs at config-parse time,
        # before ``normalize_config`` defaults omitted kwargs to ``{"use_reentrant": True}``.
        if not getattr(self, "gradient_checkpointing", False):
            errors.append(
                "requires gradient_checkpointing: true (the backward recompute re-stages experts; "
                "without it, offload is neither correct nor memory-saving)"
            )
        elif (getattr(self, "gradient_checkpointing_kwargs", None) or {}).get(
            "use_reentrant"
        ) is not False:
            errors.append(
                "requires an explicit gradient_checkpointing_kwargs.use_reentrant: false "
                "(axolotl defaults it to true when omitted; reentrant checkpointing does not "
                "re-run the block pre-hook on recompute)"
            )

        # One GPU per replica: plain DDP is fine (per-process replicas; the offloaded weights go
        # on DDP's ignore list at install), but FSDP / DeepSpeed / expert-parallel move or shard
        # these same weights and would race the stage/evict swaps.
        if getattr(self, "fsdp_config", None) or getattr(self, "fsdp", None):
            errors.append("is incompatible with FSDP (use single-GPU or plain DDP)")
        if getattr(self, "deepspeed", None):
            errors.append("is incompatible with DeepSpeed (use single-GPU or plain DDP)")
        if (getattr(self, "expert_parallel_size", None) or 1) > 1:
            errors.append(
                "is incompatible with expert_parallel (both manage the expert weights)"
            )

        if errors:
            raise ValueError(
                "expert_offload is enabled but the config is incompatible:\n  - "
                + "\n  - ".join(errors)
            )
        return self
